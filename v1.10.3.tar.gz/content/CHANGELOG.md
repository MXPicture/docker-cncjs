All notable changes are described on the [Releases](https://github.com/cheton/cnc/releases) page.

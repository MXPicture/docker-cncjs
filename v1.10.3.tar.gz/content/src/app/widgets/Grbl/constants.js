import constants from 'namespace-constants';

export const {
  MODAL_NONE,
  MODAL_CONTROLLER
} = constants('widgets/Grbl', [
  'MODAL_NONE',
  'MODAL_CONTROLLER'
]);

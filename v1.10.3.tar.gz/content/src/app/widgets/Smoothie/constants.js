import constants from 'namespace-constants';

export const {
  MODAL_NONE,
  MODAL_CONTROLLER
} = constants('widgets/Smoothie', [
  'MODAL_NONE',
  'MODAL_CONTROLLER'
]);

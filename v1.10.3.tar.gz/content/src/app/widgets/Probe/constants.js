import constants from 'namespace-constants';

export const {
  MODAL_NONE,
  MODAL_PREVIEW
} = constants('widgets/Probe', [
  'MODAL_NONE',
  'MODAL_PREVIEW'
]);

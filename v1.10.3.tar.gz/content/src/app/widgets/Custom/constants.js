import constants from 'namespace-constants';

// Modal
export const {
  MODAL_NONE,
  MODAL_SETTINGS
} = constants('widgets/Custom', [
  'MODAL_NONE',
  'MODAL_SETTINGS'
]);

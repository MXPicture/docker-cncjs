// Media Source
export const MEDIA_SOURCE_LOCAL = 'local';
export const MEDIA_SOURCE_STREAM = 'stream';

import constants from "namespace-constants";

// Modal
export const { MODAL_NONE, MODAL_SETTINGS } = constants("widgets/AxesMarlin", [
  "MODAL_NONE",
  "MODAL_SETTINGS",
]);

// Axes
export const DEFAULT_AXES = ["x", "y", "z"];

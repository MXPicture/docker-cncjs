import styled from 'styled-components';

const AxisSubscript = styled.div`
    text-align: center;
    font-size: 12px;
    line-height: 20px;
`;

export default AxisSubscript;

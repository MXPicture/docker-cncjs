import Iframe from '@trendmicro/react-iframe';

export default Iframe;

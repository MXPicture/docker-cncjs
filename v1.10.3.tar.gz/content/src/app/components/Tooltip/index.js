import '@trendmicro/react-tooltip/dist/react-tooltip.css';

export { Tooltip, Infotip } from '@trendmicro/react-tooltip';

import styled from 'styled-components';

const FormGroup = styled.div`
    margin-bottom: 12px;
`;

export default FormGroup;

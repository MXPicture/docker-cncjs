import styled from 'styled-components';

const SectionGroup = styled.div`
    margin-bottom: 24px;
`;

export default SectionGroup;

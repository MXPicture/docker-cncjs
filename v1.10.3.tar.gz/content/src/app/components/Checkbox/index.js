import '@trendmicro/react-checkbox/dist/react-checkbox.css';

export { Checkbox, CheckboxGroup } from '@trendmicro/react-checkbox';

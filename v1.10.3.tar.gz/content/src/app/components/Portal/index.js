export default from '@trendmicro/react-portal';

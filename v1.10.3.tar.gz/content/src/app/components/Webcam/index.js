import Webcam from './Webcam';

export default Webcam;

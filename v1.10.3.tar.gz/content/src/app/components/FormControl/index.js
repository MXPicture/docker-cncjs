import '@trendmicro/react-form-control/dist/react-form-control.css';
import FormControl, { Input, Select, Textarea } from '@trendmicro/react-form-control';

export { Input, Select, Textarea };
export default FormControl;

import Blink from './Blink';

export default Blink;

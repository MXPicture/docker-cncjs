export default from './Image';

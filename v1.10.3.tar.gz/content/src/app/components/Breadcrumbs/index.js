import Breadcrumbs from '@trendmicro/react-breadcrumbs';
import '@trendmicro/react-breadcrumbs/dist/react-breadcrumbs.css';

export default Breadcrumbs;

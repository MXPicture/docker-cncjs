import InlineError from './InlineError';

export default InlineError;

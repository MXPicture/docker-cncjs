import Hoverable from './Hoverable';

export default Hoverable;

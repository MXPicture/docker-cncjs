import TabularForm from './TabularForm';

export default TabularForm;

import ModalTemplate from './ModalTemplate';

export default ModalTemplate;

import Toggler from './Toggler';
import TogglerIcon from './TogglerIcon';

Toggler.Icon = TogglerIcon;

export default Toggler;

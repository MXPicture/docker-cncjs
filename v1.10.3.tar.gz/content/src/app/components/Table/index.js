import Table from '@trendmicro/react-table';
import '@trendmicro/react-table/dist/react-table.css';

export default Table;

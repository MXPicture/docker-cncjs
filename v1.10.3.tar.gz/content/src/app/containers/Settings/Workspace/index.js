import Workspace from './Workspace';

export default Workspace;

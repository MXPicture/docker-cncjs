import styled from 'styled-components';

const Error = styled.div`
    display: inline-block;
    color: #a94442;
`;

export default Error;

import MachineProfiles from './MachineProfiles';

export default MachineProfiles;

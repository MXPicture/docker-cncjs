import Controller from './Controller';

export default Controller;

import UserAccounts from './UserAccounts';

export default UserAccounts;

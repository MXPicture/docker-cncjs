// Marlin
export const MARLIN = 'Marlin';

export const QUERY_TYPE_POSITION = 'position';
export const QUERY_TYPE_TEMPERATURE = 'temperature';

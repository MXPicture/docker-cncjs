import TaskRunner from './TaskRunner';

const taskRunner = new TaskRunner();

export default taskRunner;

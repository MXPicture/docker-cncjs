# cncjs-pendant-ps3

Dual Shock / PS3 Bluetooth Remote Pendant for CNCjs

#### This project has been moved to https://github.com/cncjs/cncjs-pendant-ps3.

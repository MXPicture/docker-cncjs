# cncjs-pendant-tinyweb

A tiny web console for small 320x240 LCD display

#### This project has been moved to https://github.com/cncjs/cncjs-pendant-tinyweb.
